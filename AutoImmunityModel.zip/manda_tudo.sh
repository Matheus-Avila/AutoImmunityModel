cd NoIB/;
#sh job_1_maquinas_local > out1;
sh job_2_maquinas_local > out2;
sh job_3_maquinas_local > out3;
#sh job_4_maquinas_local > out4;
cd ../IB/;
#sh job_1_maquinas_ib_local > out4;
#sh job_2_maquinas_ib_local > out5;
#sh job_3_maquinas_ib_local > out6;
