qsub -q all.q@compute-0-17,all.q@compute-0-18 job_2_maquinas
