qsub -q all.q@compute-0-12,all.q@compute-0-14,all.q@compute-0-15,all.q@compute-0-16,all.q@compute-0-17,all.q@compute-0-18,all.q@compute-0-19 job_7_maquinas
