qsub -q all.q@compute-0-17,all.q@compute-0-18,all.q@compute-0-19,all.q@compute-0-20,all.q@compute-0-21 job_5_maquinas
