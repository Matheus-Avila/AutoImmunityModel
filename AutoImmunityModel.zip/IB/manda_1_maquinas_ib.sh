qsub -q all.q@compute-0-17 job_1_maquinas_ib
