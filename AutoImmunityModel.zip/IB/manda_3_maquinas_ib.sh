qsub -q all.q@compute-0-17,all.q@compute-0-18,all.q@compute-0-19 job_3_maquinas_ib
