qsub -q all.q@compute-0-17,all.q@compute-0-18,all.q@compute-0-19,all.q@compute-0-20,all.q@compute-0-21,all.q@compute-0-22 job_6_maquinas_ib
